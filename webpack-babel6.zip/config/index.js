
const devConfig = require('./dev.config')
const proConfig = require('./pro.config')

module.exports = process.env.NODE_ENV === "production" ? proConfig : devConfig;