module.exports = {
    // mode: "development",
    host: "localhost",
    port: 8080,
}