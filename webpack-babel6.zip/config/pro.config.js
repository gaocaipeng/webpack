module.exports = {
    // mode: "production",
    host: "www.baidu.com",
    port: 80,
}