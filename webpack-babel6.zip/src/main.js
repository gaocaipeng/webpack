import "common/css/style.css"
import "common/css/font-awesome.min.css"
import "common/sass/main.sass"

const fn = () => {
    console.log(666);
}
fn();