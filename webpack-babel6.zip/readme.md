# babel 转码器

**babel核心**】
## babel 6.0 vue脚手架在使用
- babel-cli babel的命令行执行程序
- babel-core babel转码的核心库
- bebel-preset-env babel的转码规则
- 
## babel 7.0 react脚手架在使用
- @babel/cli babel的命令行执行程序
- @babel/core babel转码的核心库
- @babel/preset-env babel的转码规则

- babel-loader webpack解析js|jsx插件