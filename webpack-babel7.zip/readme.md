# babel

## babel 6.0
babel-cli  cli代表命令行程序
babel-loader  babel是一个转码器，babel-loader 让webpack解析js，jsx
babel-core babel转码的核心库
babel-preset-env 比较新的一个转码规则，里面包含了很多es6的新的特性

## babel 7.0
@babel/cli  cli代表命令行程序
babel-loader  babel是一个转码器，babel-loader 让webpack解析js，jsx
@babel/core babel转码的核心库
@babel/preset-env 比较新的一个转码规则，里面包含了很多es6的新的特性
