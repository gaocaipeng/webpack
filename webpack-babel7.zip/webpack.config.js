const path = require('path')
const webpack = require('webpack')
const resolve = (filename) => path.join(process.cwd(), "src", filename);

module.exports = {
    /**
     * webpack mode
     * @development 开发版本
     * @production 生产版本
     * @none 无
     */
    mode: "development",
    /**
     * 入口文件
     * 单入口文件
     * 多入口文件
     */
    entry: {
        app: path.join(__dirname, 'src/main.js'),
        main: path.join(__dirname, 'src/main.js'),
        index: path.join(__dirname, 'src/main.js')
    },
    output: {
        filename: "[name].build.js",
        path: path.join(__dirname, 'dist')
    },
    // 模块解析
    module: {
        //解析规则
        rules: [{
            test: /\.(js)$/,
            loader: 'babel-loader'
        }, {
            test: /\.css$/,
            use: ["style-loader", "css-loader"]
        }, {
            test: /\.(png|gif|jpg|eot|ttf|svg|woff|woff2)$/,
            loader: "url-loader"
        }, {
            test: /\.(sass|scss)$/,
            use: ["style-loader", "css-loader", "sass-loader"]
        }]
    },
    resolve: {
        //设置
        alias: {
            "common": resolve("common")
        }
    },
    devServer: {
        //域名
        host: "localhost",
        //端口号
        port: 8080,
        //自动打开
        open: true,
        //热更新
        hot: true,
        //进度条
        progress: true,
        //开启gzip压缩
        compress: true,
        //不显示编译信息，但是显示错误
        noInfo: true,
        //不现实任何信息
        quiet: true,
        //打开新选项卡，而不是打开新窗口
        inline: true,
        //启动服务器静态资源路径
        contentBase: "./",
        //默认页面
        index: "index.html",
        //app express实例，express是nodejs小型web服务器
        before(app) {
            app.get('/api', (req, res) => {
                res.json({
                    code: 1,
                    data: [{
                        name: "小熊",
                        price: 208
                    }, {
                        name: "小猪",
                        price: 30
                    }]
                })
            })
        }
    },
    plugins: [
        new webpack.HotModuleReplacementPlugin()
    ]
}